<template>
<div>

<div>
<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<div class="container">
    <div class="row">
      <div class="col-xs-12">
<h1 class="jumbotron">Registro de productos</h1>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="empresa">Empresa</label>  
  <div class="col-md-4">
  <input id="empresa" name="empresa" type="text" placeholder="apple" v-model="newEntry.empresa" class="form-control input-md">
  <span class="help-block">help</span>  
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="titulo">Titulo</label>  
  <div class="col-md-4">
  <input id="titulo" name="titulo" type="text" placeholder="ipod" v-model="newEntry.titulo" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="descripcion">Descripcion</label>  
  <div class="col-md-4">                     
    <textarea class="form-control" id="textarea" v-model="newEntry.descripcion" name="textarea"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="precio">Precio</label>  
  <div class="col-md-4">
  <input id="precio" name="precio" type="number" placeholder="20.0" v-model="newEntry.precio" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="descuento">Descuento</label>  
  <div class="col-md-4">
  <input id="descuento" name="descuento" type="number" placeholder="5.0" v-model="newEntry.descuento" class="form-control input-md"> 
  </div>
</div>


<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="moneda">Moneda</label>  
  <div class="col-md-4">
  <input id="moneda" name="moneda" type="text" placeholder="USD" v-model="newEntry.moneda" class="form-control input-md"> 
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button @click="add()" type="button" class="btn btn-success btn-block">Agregar</button>
  </div>
</div>

</div>
</div>
</div>
</fieldset>
</form>
</div>


<div class="container">
    <div class="row">
      <div class="col-xs-12">
        <h1 class="jumbotron">Productos disponibles</h1>
<table border="1" class="table table-stripped">
<thead>
	<th>Empresa</th>
	<th>Titulo</th>
	<th>Descripcion</th>
	<th>Precio Regular</th>
    <th>Imagen del producto</th>
	<th>Descuento</th>
	<th>Precio final</th>
	<th>Moneda</th>
    
</thead>
<tbody>
	<tr v-for="data in producto " v-bind:key="data.id">
		<td>{{data.empresa}}</td>
		<td>{{data.titulo}}</td>
		<td>{{data.descripcion}}</td>
		<td>{{data.precio}}</td>
        <td>{{data.imagen}}</td>
        <td>{{data.descuento}}</td>
        <td>{{data.precio_final}}</td>
        <td>{{data.moneda}}</td>
	</tr>
 </tbody>
</table>
</div>
</div>
</div>
</div>
</template>

<script>
import axios from 'axios'; // no olvidar esto.

export default {
    mounted(){
      axios.get('http://private-519bbb-examfrontend.apiary-mock.com/products')
      .then((respuesta)  => {
          this.producto = respuesta.data.results; 
      })
    },
      data(){
      return {
          producto : [
              {
                  empresa:null,
                  titulo: null,
                  descripcion: null,
                  precio: null,
                  imagen: null,
                  descuento: null,
                  precio_final: null,
                  moneda: null
              }
          ],

           newEntry: {
            empresa:null,
            titulo: null,
            descripcion: null,
            precio: null,
            imagen: null,
            descuento: null,
            precio_final: null,
            moneda: null
        }
      }
   },
   methods: {
        add() {
          this.producto.push({
            empresa: this.newEntry.empresa,
            titulo: this.newEntry.titulo,
            descripcion: this.newEntry.descripcion,
            precio: parseFloat(this.newEntry.precio),
            imagen: 'imagen.jpg',
            descuento: parseFloat(this.newEntry.descuento),
            precio_final: (parseFloat(this.newEntry.precio)-parseFloat(this.newEntry.descuento)),
            moneda: this.newEntry.moneda
          });

          this.newEntry.empresa = '';
          this.newEntry.titulo = '';
          this.newEntry.descripcion = '';
          this.newEntry.precio = null;
          this.newEntry.descuento = null;
          thi.newEntry.moneda = null;
        }
    }
  }
</script>

<style >

</style>