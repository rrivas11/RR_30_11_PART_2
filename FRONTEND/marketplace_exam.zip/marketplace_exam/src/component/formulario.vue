<template>
<div>
<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<legend>Registro de productos</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="empresa">Empresa</label>  
  <div class="col-md-4">
  <input id="empresa" name="empresa" type="text" placeholder="apple" v-model="newEntry.empresa" class="form-control input-md">
  <span class="help-block">help</span>  
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="titulo">Titulo</label>  
  <div class="col-md-4">
  <input id="titulo" name="titulo" type="text" placeholder="ipod" v-model="newEntry.titulo" class="form-control input-md">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="precio">Precio</label>  
  <div class="col-md-4">
  <input id="precio" name="precio" type="text" placeholder="10.0" v-model="newEntry.precio" class="form-control input-md">
    
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="singlebutton"></label>
  <div class="col-md-4">
    <button @click="add()" id="singlebutton" name="singlebutton" class="btn btn-primary">Agregar</button>
  </div>
</div>

</fieldset>
</form>
</div>
</template>

<script>
export default {
    data () { 
      return {
        newEntry: {
            empresa:null,
            titulo: null,
            descripcion: null,
            precio: null,
            imagen: null,
            descuento: null,
            precio_final: null,
            moneda: null
        }
      }
    },
    methods: {
        add() {
          this.producto.push({
            empresa: this.newEntry.empresa,
            titulo: parseFloat(this.newEntry.precio),
            descripcion: null,
            precio: this.newEntry.precio,
            imagen: null,
            descuento: null,
            precio_final: null,
            moneda: null
          });

          this.newEntry.name = '';
          this.newEntry.amount = 0;
        }
    }
}
</script>

<style >

</style>