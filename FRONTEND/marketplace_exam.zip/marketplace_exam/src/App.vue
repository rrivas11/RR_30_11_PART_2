<template>
<div>

<disponibles></disponibles> 
</div>
</template>

<script>
import disponibles from "./component/disponibles.vue"
import formulario from "./component/formulario.vue" 
export default {
    components: {disponibles},
    //components: {formulario}, 
  data () {
    return {
     
    }
  }
}
</script>

<style>

</style>
